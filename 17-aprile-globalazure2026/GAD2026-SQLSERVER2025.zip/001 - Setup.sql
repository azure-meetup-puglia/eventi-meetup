/*
    https://techcommunity.microsoft.com/blog/coreinfrastructureandsecurityblog/ollama-on-https-for-sql-server/4458309
*/



USE [master]
RESTORE DATABASE [WideWorldImporters] 
FROM  DISK = N'D:\SQL_BAK\WideWorldImporters-Full.bak' 
WITH  FILE = 1,  
MOVE N'WWI_Primary' TO N'D:\SQL_DATA\WideWorldImporters.mdf',  
MOVE N'WWI_UserData' TO N'D:\SQL_DATA\WideWorldImporters_UserData.ndf',  
MOVE N'WWI_Log' TO N'D:\SQL_LOG\WideWorldImporters.ldf',  
MOVE N'WWI_InMemory_Data_1' TO N'D:\SQL_DATA\WideWorldImporters_InMemory_Data_1',  
NOUNLOAD,  STATS = 5, REPLACE
GO

USE [master]
RESTORE DATABASE [AdventureWorksOnPrem] 
FROM  DISK = N'D:\SQL_BAK\AdventureWorks2022.bak' 
WITH  FILE = 1,  
MOVE N'AdventureWorks2022' TO N'D:\SQL_DATA\AdventureWorksOnPrem.mdf',  
MOVE N'AdventureWorks2022_log' TO N'D:\SQL_LOG\AdventureWorksOnPrem_log.ldf',  
NOUNLOAD,  REPLACE,  STATS = 5
GO



use [master]
GO
ALTER DATABASE WideWorldImporters SET COMPATIBILITY_LEVEL = 170 
WITH ROLLBACK IMMEDIATE
GO

use [WideWorldImporters]
GO

sp_configure 'external rest endpoint enabled',1
reconfigure with override
go



