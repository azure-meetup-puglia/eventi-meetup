/*
    c:\docker\ollama> docker exec ollama-https ollama pull nomic-embed-text
    c:\docker\ollama> docker exec ollama-https ollama pull phi3:mini
*/

use [WideWorldImporters]
GO

IF EXISTS(select * from sys.external_models WHERE [name] = 'NomicLocal')
BEGIN
    DROP EXTERNAL MODEL NomicLocal
END;

/*
    docker exec ollama-https ollama pull nomic-embed-text
    Caratteristiche tecniche
    ------------------------------------------------------
    Dimensioni embedding: 768
    Context window: fino a ~8K token
    Output: float[]
    Velocissimo (CPU friendly)
    Indice vettoriale (FAISS, pgvector, SQL Server VECTOR)
*/

CREATE EXTERNAL MODEL NomicLocal
AUTHORIZATION dbo
WITH (
      LOCATION = 'https://localhost/api/embed',
      API_FORMAT = 'ollama',
      MODEL_TYPE = EMBEDDINGS,
      MODEL = 'nomic-embed-text' --Trasforma il testo in vettori (768 dimensioni)
);
GO

--test it
SELECT
    AI_GENERATE_EMBEDDINGS(
        N'Global Azure Day 2026 - Benvenuti a Bari'
        USE MODEL NomicLocal
    ) AS Embedding;




/* 
    esempio 2 
    c:\docker\ollama> docker exec ollama-https ollama pull mxbai-embed-large
    1024 embedding dimension, più lento di nomic-embed-text ma con potenzialmente migliori performance in scenari complessi
*/
CREATE EXTERNAL MODEL mxbai_embed_large_Local
AUTHORIZATION dbo
WITH (
      LOCATION = 'https://localhost/api/embed',
      API_FORMAT = 'Ollama',
      MODEL_TYPE = EMBEDDINGS,
      MODEL = 'mxbai-embed-large' --Trasforma il testo in vettori (1024 dimensioni)
);
GO

SELECT
    AI_GENERATE_EMBEDDINGS(
        N'Global Azure Day 2026 - Benvenuti a Bari'
        USE MODEL mxbai_embed_large_Local
    ) AS Embedding;
