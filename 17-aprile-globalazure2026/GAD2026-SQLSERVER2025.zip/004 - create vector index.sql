/*
	to enable semantic search capabilities on StockItems, we will create a dedicated table to store embeddings 
	(no chunking in this example) along with a vector index optimized for cosine similarity
*/



use [WideWorldImporters]
GO

CREATE TABLE [Warehouse].[StockItemsEmbedding](StockItemEmbeddingID 
    int identity (1,1) PRIMARY KEY, 
    StockItemId int, 
    Embedding vector(768))
GO

/* ~ 20 secs */
INSERT INTO [Warehouse].[StockItemsEmbedding]
SELECT 
    si.StockItemID, 
    AI_GENERATE_EMBEDDINGS(si.SearchDetails USE MODEL NomicLocal) 
    /* Generate embeddings from declared external model */
FROM
    [Warehouse].[StockItems] si
GO

/* Check */
SELECT * FROM [Warehouse].[StockItemsEmbedding]
GO


SELECT * FROM sys.types WHERE name = 'vector';

--necessario per poter creare indici vettoriali
ALTER DATABASE SCOPED CONFIGURATION
SET PREVIEW_FEATURES = ON;

/*
ALTER DATABASE SCOPED CONFIGURATION
SET PREVIEW_FEATURES = OFF;
*/

--attenzione, la tabella read-only
CREATE VECTOR INDEX StockItemsEmbedding_vector_index
ON [Warehouse].[StockItemsEmbedding] (Embedding) 
WITH (
    METRIC = 'COSINE', /* 
                            cosine - Cosine distance
                            euclidean - Euclidean distance, 
                            dot - (Negative) Dot product 
                       */
    TYPE = 'DiskANN', /* Only DiskANN is currently supported */
    MAXDOP = 8)
GO







SELECT
    i.name AS index_name,
    t.name AS table_name,
    JSON_VALUE(v.build_parameters, '$.Version') AS index_version,
    CASE
        WHEN JSON_VALUE(v.build_parameters, '$.Version') >= '3'
            THEN 'Uses latest version (no migration required)'
        WHEN JSON_VALUE(v.build_parameters, '$.Version') < '3'
            THEN 'Created using an earlier version (migration recommended)'
        ELSE 'Unknown format'
    END AS migration_status
FROM sys.vector_indexes AS v
    INNER JOIN sys.indexes AS i
        ON v.object_id = i.object_id
        AND v.index_id = i.index_id
    INNER JOIN sys.tables AS t
        ON v.object_id = t.object_id
ORDER BY t.name, i.name;