use [WideWorldImporters]
GO


--CREATE VECTOR INDEX StockItemsEmbedding_vector_index
--ON [Warehouse].[StockItemsEmbedding] (Embedding) 
--WITH (
--    METRIC = 'cosine', /* 
--                            cosine - Cosine distance
--                            euclidean - Euclidean distance, 
--                            dot - (Negative) Dot product 
--                       */
--    TYPE = 'DiskANN', /* Only DiskANN is currently supported */
--    MAXDOP = 8)
--GO


/* User Input */
DECLARE @UserInput nvarchar(max) = 'Which product is best suited for shipping small fragile items?'

/* and Generate embeddings for user input */
DECLARE @UserInputV vector(768) = AI_GENERATE_EMBEDDINGS(@UserInput USE MODEL NomicLocal) --768 deve corrispondere alla dimensione dell'embedding generato dal modello

DECLARE @ModelInput nvarchar(max)
DECLARE @Payload nvarchar(max)
DECLARE @Response nvarchar(max)

/* 
    Similarity Search on StockItems and Model Input creation
    VECTOR_SEARCH preview feature allows to perform similarity search on vector columns using the declared external model, 
    without the need to manage the embedding generation and storage.
*/
SELECT 
    --aggiungo contesto al prompt
    @ModelInput = STRING_AGG('ProductDetails: ' + si.SearchDetails + 'UnitPrice: ' + CAST(si.UnitPrice AS nvarchar(max)), ' \n\n') 
FROM
    VECTOR_SEARCH(
        TABLE = [Warehouse].[StockItemsEmbedding]  as sie, 
        COLUMN = Embedding, 
        SIMILAR_TO = @UserInputV, 
        METRIC = 'cosine', --cosine distance
        TOP_N = 10 -- top 10 results
    ) 
    JOIN [Warehouse].[StockItems] si ON si.StockItemId = sie.StockItemId

/* Generate payload for response generation */
SELECT  @Payload= 
'{"model": "phi3:mini", "stream": false, "prompt":"You are acting as a customer advisor responsible for recommending the most suitable products based on customer needs, providing clear and personalized suggestions. \n Question : ' 
+ @UserInput  
+ '\n\nList of Items : \n'  
+ @ModelInput + '"}';

EXEC sp_invoke_external_rest_endpoint
    @url = 'https://localhost/api/generate',
    @method = 'POST',
    @payload = @Payload,
    @timeout = 230,
    @response = @response OUTPUT;


PRINT JSON_VALUE(@response, '$.result.response')


/*
    risultati non deterministici:
    Vector searchANN ≠ deterministico (DiskANN non deterministico)
    ad ogni esecuzione il grafo ANN può esplorare percorsi diversi
    
    Microsoft lo dice esplicitamente quando introduce la differenza tra:
       - Exact search (k‑NN) → deterministica ma costosa
       - Approximate search (ANN) → veloce ma non deterministica
*/


/* fine */

/* torna alle slide */