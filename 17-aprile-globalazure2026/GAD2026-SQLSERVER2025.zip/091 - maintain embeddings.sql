use WideWorldImporters
go

alter table [Warehouse].[StockItemsEmbedding]
add [vectors_update_info] nvarchar(max) null ;
go


/*
	https://devblogs.microsoft.com/azure-sql/diskann-vector-index-improvements/
	18th March 2026 - Davide and Pooja are happy to announce that the DiskANN Vector Index public preview just received a major upgrade, 
	removing the initial constraints (your table became read‑only) 
	and unlocking high‑performance vector search at scale 
	without sacrificing day‑to‑day operations
*/
-- Check if the new DMV exists
SELECT OBJECT_ID('sys.dm_db_vector_indexes') AS new_dmv_available;
--If this returns NULL, your region hasn’t received the deployment yet. 
--Check back in a few days! If instead it returns a number, you’re good to go!



--read-only table, we need to drop and recreate the vector index to allow updates on the embedding column
drop index StockItemsEmbedding_vector_index
on [Warehouse].[StockItemsEmbedding]
go

/*
    Create a procedure to get the embeddings for the input text 
*/
create or alter procedure dbo.get_embedding
	@inputText nvarchar(1000),
	@embedding vector(768) output
	as
		SELECT @embedding = AI_GENERATE_EMBEDDINGS(@inputText USE MODEL NomicLocal)

	/* test
		declare @embedding vector(768)
		exec dbo.get_embedding 'test', @embedding output
		select @embedding
	*/

go





/*
	Create trigger to update embeddings
	when "content" column is changed
*/
create or alter trigger tr_update_embeddings
on [Warehouse].[StockItems] 
after insert, update
as
	set nocount on;
	--(concat([StockItemName],N' ',[MarketingComments]))
	if not(update(StockItemName)) and not(update(MarketingComments)) return;

	declare c cursor fast_forward read_only
	for select [StockItemId], (concat([StockItemName],N' ',[MarketingComments])) as SearchDetails from inserted
	order by StockItemId;

	declare @StockItemId int, @SearchDetails nvarchar(max);

	open c;
	fetch next from c into @StockItemId, @SearchDetails
	while @@fetch_status = 0
	begin
		begin try
			declare @retval int;
  
			if update(StockItemName) or update(MarketingComments) begin		
				--declare @content nvarchar(max) = (concat([StockItemName],N' ',[MarketingComments]));
				declare @embedding vector(768);
				exec @retval = [dbo].[get_embedding] @SearchDetails, @embedding output with result sets none
				update [Warehouse].[StockItemsEmbedding]  set Embedding = @embedding where StockItemId = @StockItemId
			end

			update [Warehouse].[StockItemsEmbedding] 
			set [vectors_update_info] = json_object('status':'updated', 'timestamp':CURRENT_TIMESTAMP)
			where StockItemId = @StockItemId
		end try
		begin catch
			update [Warehouse].[StockItemsEmbedding] 
			set [vectors_update_info] = json_object('status':'error', 'timestamp':CURRENT_TIMESTAMP)
			where StockItemId = @StockItemId
		end catch
		fetch next from c into @StockItemId, @SearchDetails

	end
	close c
	deallocate c
go

select * from [Warehouse].[StockItemsEmbedding] where stockitemid = 1
select MarketingComments from [Warehouse].[StockItems] where stockitemid = 1

update [Warehouse].[StockItems] 
set MarketingComments = 'questo articolo è proprio per chi indossa occhiali'
where stockitemid = 1

select * from [Warehouse].[StockItemsEmbedding] where stockitemid = 1
select MarketingComments from [Warehouse].[StockItems] where stockitemid = 1


/* TORNA ALLE SLIDE */