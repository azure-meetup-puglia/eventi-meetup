use AdventureWorksOnPrem
go

SELECT FULLTEXTSERVICEPROPERTY('IsFullTextInstalled') AS IsFullTextInstalled;
GO

CREATE UNIQUE INDEX UX_ProductDescription_ProductDescriptionID
ON Production.ProductDescription(ProductDescriptionID);
GO

CREATE FULLTEXT CATALOG FTC_ProductDescription
WITH ACCENT_SENSITIVITY = OFF;
GO

CREATE FULLTEXT INDEX ON Production.ProductDescription
(
    Description LANGUAGE 1033  -- 1033 = English
    /* 
       optional, if specified is used to index data stored in char, nchar, varchar, nvarchar, text and ntext
       columns. Used at query time.
       - the word breaker (delimiters based on the lexical rules of the language) 
       - stemmers (generate inflectional forms of a word based on the language) - running, runs, ran -> run) 
       are used by full-text queries on the columns.
    */
)
KEY INDEX UX_ProductDescription_ProductDescriptionID
ON FTC_ProductDescription;
GO




/* cerchiamo materiale per sport estremi all'aperto */
/*
    Le query full-text usano un piccolo insieme di predicati Transact-SQL (CONTAINS e FREETEXT) 
    e funzioni (CONTAINSTABLE e FREETEXTTABLE). 
    Gli obiettivi di ricerca di un determinato scenario influiscono sulla struttura delle query full-text
*/

/* LIKE */
SELECT Description FROM Production.ProductDescription
WHERE Description LIKE '%Show me stuff for extreme outdoor sports%';
GO
/* CONTAINS */
SELECT Description FROM Production.ProductDescription
WHERE CONTAINS(Description,'"Show me stuff for extreme outdoor sports"');
GO
/* FREETEXT */
SELECT Description FROM Production.ProductDescription
WHERE FREETEXT(Description,'Show me stuff for extreme outdoor sports');
GO

/*
    for ranked results use
    CONTAINSTABLE and FREETEXTTABLE
*/

